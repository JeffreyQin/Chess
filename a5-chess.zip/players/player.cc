#include "player.h"

Player::Player(Board *b, int color): board{b}, color{color} {}
